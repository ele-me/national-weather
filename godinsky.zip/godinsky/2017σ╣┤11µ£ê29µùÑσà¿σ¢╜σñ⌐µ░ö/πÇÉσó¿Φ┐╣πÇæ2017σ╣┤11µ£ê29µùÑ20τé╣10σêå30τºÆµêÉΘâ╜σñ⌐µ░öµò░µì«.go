{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "武侯区",
            "co": "7",
            "coC": "0.7",
            "no2": "34",
            "no2C": "68.0",
            "o3": "4",
            "o3C": "12.0",
            "pm10": "62",
            "pm10C": "74.0",
            "pm25": "68",
            "pm25C": "49.0",
            "pubtime": "1511953200000",
            "rank": "305/606",
            "so2": "3",
            "so2C": "10.0",
            "value": "68"
        },
        "aqiForecast": [
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 00:00:00",
                "value": 172
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-29 18:00:00",
                "value": 65
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-29 19:00:00",
                "value": 91
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-29 19:00:00",
                "value": 94
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-29 19:00:00",
                "value": 107
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-29 19:00:00",
                "value": 117
            },
            {
                "date": "2017-12-04",
                "publishTime": "2017-11-29 19:00:00",
                "value": 94
            }
        ],
        "city": {
            "cityId": 285195,
            "counname": "中国",
            "name": "武侯区",
            "pname": "四川省",
            "timezone": "8"
        },
        "condition": {
            "condition": "阴",
            "conditionId": "13",
            "humidity": "77",
            "icon": "2",
            "pressure": "1024",
            "realFeel": "13",
            "sunRise": "2017-11-29 07:41:00",
            "sunSet": "2017-11-29 18:02:00",
            "temp": "11",
            "tips": "天冷了，该加衣服了！",
            "updatetime": "2017-11-29 20:00:00",
            "uvi": "0",
            "windDir": "东北风",
            "windLevel": "1",
            "windSpeed": "0.9"
        },
        "forecast": [
            {
                "conditionDay": "小雨",
                "conditionIdDay": "7",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 14:31:00",
                "moonset": "2017-11-29 02:35:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 07:40:00",
                "sunset": "2017-11-28 18:03:00",
                "tempDay": "14",
                "tempNight": "4",
                "updatetime": "2017-11-28 23:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "7",
                "conditionNight": "小雨",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 15:08:00",
                "moonset": "2017-11-30 03:36:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 07:41:00",
                "sunset": "2017-11-29 18:02:00",
                "tempDay": "15",
                "tempNight": "8",
                "updatetime": "2017-11-29 19:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "7",
                "conditionNight": "小雨",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 15:46:00",
                "moonset": "2017-12-01 04:38:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 07:42:00",
                "sunset": "2017-11-30 18:02:00",
                "tempDay": "14",
                "tempNight": "7",
                "updatetime": "2017-11-29 19:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 16:26:00",
                "moonset": "2017-12-02 05:45:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 07:43:00",
                "sunset": "2017-12-01 18:02:00",
                "tempDay": "12",
                "tempNight": "7",
                "updatetime": "2017-11-29 19:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 17:11:00",
                "moonset": "2017-12-03 06:52:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 07:44:00",
                "sunset": "2017-12-02 18:02:00",
                "tempDay": "12",
                "tempNight": "8",
                "updatetime": "2017-11-29 19:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Full",
                "moonrise": "2017-12-03 18:01:00",
                "moonset": "2017-12-04 08:01:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 07:45:00",
                "sunset": "2017-12-03 18:02:00",
                "tempDay": "12",
                "tempNight": "8",
                "updatetime": "2017-11-29 19:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-11-29 18:57:00",
                "moonset": "2017-11-29 08:01:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 07:45:00",
                "sunset": "2017-12-04 18:02:00",
                "tempDay": "12",
                "tempNight": "7",
                "updatetime": "2017-11-29 19:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-11-30 19:58:00",
                "moonset": "2017-11-30 09:08:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 07:46:00",
                "sunset": "2017-12-05 18:02:00",
                "tempDay": "13",
                "tempNight": "4",
                "updatetime": "2017-11-29 19:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 21:02:00",
                "moonset": "2017-12-06 10:11:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 07:47:00",
                "sunset": "2017-12-06 18:02:00",
                "tempDay": "13",
                "tempNight": "2",
                "updatetime": "2017-11-29 19:10:00",
                "windDirDay": "微风",
                "windDirNight": "东风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 22:08:00",
                "moonset": "2017-12-07 11:08:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 07:48:00",
                "sunset": "2017-12-07 18:02:00",
                "tempDay": "10",
                "tempNight": "2",
                "updatetime": "2017-11-29 19:10:00",
                "windDirDay": "东风",
                "windDirNight": "东风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-03 23:13:00",
                "moonset": "2017-12-03 11:57:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 07:48:00",
                "sunset": "2017-12-08 18:03:00",
                "tempDay": "12",
                "tempNight": "3",
                "updatetime": "2017-11-29 19:10:00",
                "windDirDay": "东风",
                "windDirNight": "东北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "None",
                "moonset": "2017-12-10 12:41:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 07:49:00",
                "sunset": "2017-12-09 18:03:00",
                "tempDay": "10",
                "tempNight": "2",
                "updatetime": "2017-11-29 19:10:00",
                "windDirDay": "东南风",
                "windDirNight": "东北风",
                "windLevelDay": "2",
                "windLevelNight": "1",
                "windSpeedDay": "3.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "8",
                "conditionNight": "雨",
                "moonphase": "Last",
                "moonrise": "2017-12-04 00:15:00",
                "moonset": "2017-12-04 13:21:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 07:50:00",
                "sunset": "2017-12-10 18:03:00",
                "tempDay": "7",
                "tempNight": "3",
                "updatetime": "2017-11-29 19:10:00",
                "windDirDay": "东南风",
                "windDirNight": "东南风",
                "windLevelDay": "2",
                "windLevelNight": "1",
                "windSpeedDay": "3.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "8",
                "conditionNight": "雨",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-12 01:15:00",
                "moonset": "2017-12-12 13:57:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 07:51:00",
                "sunset": "2017-12-11 18:03:00",
                "tempDay": "7",
                "tempNight": "4",
                "updatetime": "2017-11-29 19:10:00",
                "windDirDay": "东风",
                "windDirNight": "东风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "8",
                "conditionNight": "雨",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-05 02:12:00",
                "moonset": "2017-12-05 14:32:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 07:51:00",
                "sunset": "2017-12-12 18:03:00",
                "tempDay": "7",
                "tempNight": "4",
                "updatetime": "2017-11-29 19:10:00",
                "windDirDay": "东风",
                "windDirNight": "东南风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "8",
                "conditionNight": "雨",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-14 03:08:00",
                "moonset": "2017-12-14 15:06:00",
                "predictDate": "2017-12-13",
                "sunrise": "2017-12-13 07:52:00",
                "sunset": "2017-12-13 18:04:00",
                "tempDay": "9",
                "tempNight": "4",
                "updatetime": "2017-11-29 19:10:00",
                "windDirDay": "东风",
                "windDirNight": "东北风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            }
        ],
        "hourly": [
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "18",
                "humidity": "57",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "12",
                "temp": "12",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "60",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "11",
                "temp": "12",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "64",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "11",
                "temp": "11",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "65",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "10",
                "temp": "10",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "9"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "64",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "10",
                "temp": "9",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "73",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "7",
                "temp": "8",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "74",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "9",
                "temp": "8",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "1",
                "humidity": "75",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "9",
                "temp": "8",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "2",
                "humidity": "77",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "8",
                "temp": "8",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "3",
                "humidity": "80",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "8",
                "temp": "8",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "4",
                "humidity": "84",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "8",
                "temp": "8",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "5",
                "humidity": "87",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "8",
                "temp": "8",
                "uvi": "0",
                "windDir": "W",
                "windSpeed": "5"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "6",
                "humidity": "89",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "8",
                "temp": "7",
                "uvi": "0",
                "windDir": "W",
                "windSpeed": "5"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "7",
                "humidity": "93",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "7",
                "temp": "7",
                "uvi": "0",
                "windDir": "W",
                "windSpeed": "5"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "8",
                "humidity": "93",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "8",
                "temp": "7",
                "uvi": "1",
                "windDir": "W",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "9",
                "humidity": "85",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "11",
                "temp": "9",
                "uvi": "2",
                "windDir": "WNW",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "10",
                "humidity": "69",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "14",
                "temp": "11",
                "uvi": "3",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "11",
                "humidity": "55",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "17",
                "temp": "12",
                "uvi": "3",
                "windDir": "NNW",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "12",
                "humidity": "47",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "18",
                "temp": "13",
                "uvi": "4",
                "windDir": "N",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "13",
                "humidity": "42",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "18",
                "temp": "13",
                "uvi": "3",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "14",
                "humidity": "40",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "18",
                "temp": "14",
                "uvi": "3",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "15",
                "humidity": "36",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "18",
                "temp": "14",
                "uvi": "2",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "16",
                "humidity": "36",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "16",
                "temp": "14",
                "uvi": "1",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "17",
                "humidity": "37",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "14",
                "temp": "13",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "18",
                "humidity": "43",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "12",
                "temp": "12",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "19",
                "humidity": "45",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "12",
                "temp": "12",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "9"
            }
        ],
        "limit": [
            {
                "date": "2017-11-28",
                "prompt": "27"
            },
            {
                "date": "2017-11-29",
                "prompt": "38"
            },
            {
                "date": "2017-11-30",
                "prompt": "49"
            },
            {
                "date": "2017-12-01",
                "prompt": "50"
            },
            {
                "date": "2017-12-02",
                "prompt": "W"
            },
            {
                "date": "2017-12-03",
                "prompt": "W"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "建议用露质面霜打底，水质无油粉底霜，透明粉饼，粉质胭脂。",
                    "level": "6",
                    "name": "化妆指数",
                    "status": "控油"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒可能发生，体质较弱的童鞋们要注意了，要及时增减衣物，适时补充水分，坚持锻炼身体。",
                    "level": "2",
                    "name": "感冒指数",
                    "status": "可能"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "雨(雪)水和泥水会弄脏您的爱车，不适宜清洗车辆。",
                    "level": "10",
                    "name": "洗车指数",
                    "status": "不宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "易感人群应适当减少室外活动。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "中"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "天气偏凉，增加衣物厚度。",
                    "level": "8",
                    "name": "穿衣指数",
                    "status": "温凉"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "辐射弱，涂擦SPF8-12防晒护肤品。",
                    "level": "1",
                    "name": "紫外线指数",
                    "status": "最弱"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "气压有点偏低了，较不适宜在户外进行剧烈运动。",
                    "level": "12",
                    "name": "运动指数",
                    "status": "不适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "气压下降，鱼儿不易咬钩，不宜垂钓。",
                    "level": "9",
                    "name": "钓鱼指数",
                    "status": "较适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 2,
            "timestamp": 1510356603000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
