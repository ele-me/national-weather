{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "东城区",
            "co": "4",
            "coC": "0.4",
            "no2": "14",
            "no2C": "28.0",
            "o3": "14",
            "o3C": "44.0",
            "pm10": "27",
            "pm10C": "27.0",
            "pm25": "16",
            "pm25C": "11.0",
            "pubtime": "1511935200000",
            "rank": "67/605",
            "so2": "1",
            "so2C": "3.0",
            "value": "27"
        },
        "aqiForecast": [
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 00:00:00",
                "value": 74
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-29 13:00:00",
                "value": 22
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-29 14:00:00",
                "value": 55
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-29 14:00:00",
                "value": 60
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-29 14:00:00",
                "value": 70
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-29 14:00:00",
                "value": 59
            },
            {
                "date": "2017-12-04",
                "publishTime": "2017-11-29 14:00:00",
                "value": 50
            }
        ],
        "city": {
            "cityId": 284609,
            "counname": "中国",
            "name": "东城区",
            "pname": "北京市",
            "timezone": "8"
        },
        "condition": {
            "condition": "晴",
            "conditionId": "1",
            "humidity": "16",
            "icon": "0",
            "pressure": "1034",
            "realFeel": "0",
            "sunRise": "2017-11-29 07:14:00",
            "sunSet": "2017-11-29 16:51:00",
            "temp": "0",
            "tips": "天气干冷，穿厚一点吧！",
            "updatetime": "2017-11-29 15:00:00",
            "uvi": "1",
            "windDir": "南风",
            "windLevel": "2",
            "windSpeed": "2.45"
        },
        "forecast": [
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 13:46:00",
                "moonset": "2017-11-29 01:41:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 07:13:00",
                "sunset": "2017-11-28 16:51:00",
                "tempDay": "7",
                "tempNight": "-3",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "西北风",
                "windDirNight": "东北风",
                "windLevelDay": "4",
                "windLevelNight": "3",
                "windSpeedDay": "7.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 14:17:00",
                "moonset": "2017-11-30 02:46:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 07:14:00",
                "sunset": "2017-11-29 16:51:00",
                "tempDay": "1",
                "tempNight": "-6",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "南风",
                "windDirNight": "东北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 14:51:00",
                "moonset": "2017-12-01 03:54:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 07:15:00",
                "sunset": "2017-11-30 16:50:00",
                "tempDay": "3",
                "tempNight": "-6",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西风",
                "windDirNight": "西风",
                "windLevelDay": "3",
                "windLevelNight": "2",
                "windSpeedDay": "5.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 15:27:00",
                "moonset": "2017-12-02 05:05:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 07:16:00",
                "sunset": "2017-12-01 16:50:00",
                "tempDay": "5",
                "tempNight": "-5",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "南风",
                "windDirNight": "南风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 16:06:00",
                "moonset": "2017-12-03 06:17:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 07:17:00",
                "sunset": "2017-12-02 16:50:00",
                "tempDay": "6",
                "tempNight": "-5",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西南风",
                "windDirNight": "东北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "Full",
                "moonrise": "2017-12-03 16:52:00",
                "moonset": "2017-12-04 07:30:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 07:18:00",
                "sunset": "2017-12-03 16:50:00",
                "tempDay": "7",
                "tempNight": "-3",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-04 17:45:00",
                "moonset": "2017-12-05 08:38:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 07:19:00",
                "sunset": "2017-12-04 16:49:00",
                "tempDay": "3",
                "tempNight": "-5",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西风",
                "windDirNight": "西北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-05 18:44:00",
                "moonset": "2017-12-06 09:41:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 07:20:00",
                "sunset": "2017-12-05 16:49:00",
                "tempDay": "6",
                "tempNight": "-5",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西南风",
                "windDirNight": "西北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 19:49:00",
                "moonset": "2017-12-07 10:35:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 07:21:00",
                "sunset": "2017-12-06 16:49:00",
                "tempDay": "5",
                "tempNight": "-3",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西南风",
                "windDirNight": "西北风",
                "windLevelDay": "2",
                "windLevelNight": "1",
                "windSpeedDay": "3.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 20:58:00",
                "moonset": "2017-12-08 11:23:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 07:22:00",
                "sunset": "2017-12-07 16:49:00",
                "tempDay": "3",
                "tempNight": "-3",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西风",
                "windDirNight": "西北风",
                "windLevelDay": "1",
                "windLevelNight": "3",
                "windSpeedDay": "1.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-08 22:06:00",
                "moonset": "2017-12-09 12:03:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 07:23:00",
                "sunset": "2017-12-08 16:49:00",
                "tempDay": "3",
                "tempNight": "-7",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西北风",
                "windDirNight": "西北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-09 23:13:00",
                "moonset": "2017-12-10 12:38:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 07:24:00",
                "sunset": "2017-12-09 16:49:00",
                "tempDay": "-1",
                "tempNight": "-8",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西风",
                "windDirNight": "西风",
                "windLevelDay": "4",
                "windLevelNight": "3",
                "windSpeedDay": "7.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "Last",
                "moonrise": "None",
                "moonset": "2017-12-10 12:38:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 07:24:00",
                "sunset": "2017-12-10 16:49:00",
                "tempDay": "1",
                "tempNight": "-8",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西风",
                "windDirNight": "西风",
                "windLevelDay": "3",
                "windLevelNight": "2",
                "windSpeedDay": "5.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-11 00:17:00",
                "moonset": "2017-12-11 13:10:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 07:25:00",
                "sunset": "2017-12-11 16:49:00",
                "tempDay": "2",
                "tempNight": "-7",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "少云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-12 01:20:00",
                "moonset": "2017-12-12 13:40:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 07:26:00",
                "sunset": "2017-12-12 16:49:00",
                "tempDay": "2",
                "tempNight": "-7",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "东南风",
                "windDirNight": "东北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-13 02:20:00",
                "moonset": "2017-12-13 14:09:00",
                "predictDate": "2017-12-13",
                "sunrise": "2017-12-13 07:27:00",
                "sunset": "2017-12-13 16:50:00",
                "tempDay": "2",
                "tempNight": "-8",
                "updatetime": "2017-11-29 14:10:08",
                "windDirDay": "西北风",
                "windDirNight": "西北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            }
        ],
        "hourly": [
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "13",
                "humidity": "12",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "0",
                "uvi": "1",
                "windDir": "SSW",
                "windSpeed": "11"
            },
            {
                "condition": "多云",
                "date": "2017-11-29",
                "hour": "14",
                "humidity": "15",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "0",
                "uvi": "1",
                "windDir": "SSW",
                "windSpeed": "12"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "15",
                "humidity": "19",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "0",
                "uvi": "1",
                "windDir": "SW",
                "windSpeed": "12"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "16",
                "humidity": "24",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "-1",
                "uvi": "0",
                "windDir": "SW",
                "windSpeed": "11"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "17",
                "humidity": "28",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-4",
                "temp": "-2",
                "uvi": "0",
                "windDir": "SW",
                "windSpeed": "11"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "18",
                "humidity": "31",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-4",
                "temp": "-3",
                "uvi": "0",
                "windDir": "SW",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "32",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "-4",
                "uvi": "0",
                "windDir": "S",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "32",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "-5",
                "uvi": "0",
                "windDir": "SSE",
                "windSpeed": "5"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "34",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-4",
                "temp": "-5",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "35",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-6",
                "temp": "-5",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "36",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-7",
                "temp": "-6",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "34",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-8",
                "temp": "-6",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "1",
                "humidity": "32",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-8",
                "temp": "-6",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "11"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "2",
                "humidity": "29",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-9",
                "temp": "-6",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "12"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "3",
                "humidity": "27",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-10",
                "temp": "-6",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "12"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "4",
                "humidity": "27",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-12",
                "temp": "-6",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "16"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "5",
                "humidity": "26",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-12",
                "temp": "-5",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "18"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "6",
                "humidity": "26",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-12",
                "temp": "-4",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "18"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "7",
                "humidity": "26",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-11",
                "temp": "-4",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "18"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "8",
                "humidity": "23",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-9",
                "temp": "-3",
                "uvi": "1",
                "windDir": "NW",
                "windSpeed": "16"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "9",
                "humidity": "20",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-6",
                "temp": "-2",
                "uvi": "1",
                "windDir": "NW",
                "windSpeed": "16"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "10",
                "humidity": "16",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "0",
                "uvi": "2",
                "windDir": "WNW",
                "windSpeed": "14"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "11",
                "humidity": "13",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "1",
                "uvi": "2",
                "windDir": "WNW",
                "windSpeed": "14"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "12",
                "humidity": "11",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "1",
                "temp": "2",
                "uvi": "2",
                "windDir": "W",
                "windSpeed": "14"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "13",
                "humidity": "10",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "2",
                "temp": "2",
                "uvi": "2",
                "windDir": "WSW",
                "windSpeed": "12"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "14",
                "humidity": "11",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "3",
                "temp": "3",
                "uvi": "2",
                "windDir": "SW",
                "windSpeed": "12"
            }
        ],
        "limit": [
            {
                "date": "2017-11-28",
                "prompt": "27"
            },
            {
                "date": "2017-11-29",
                "prompt": "38"
            },
            {
                "date": "2017-11-30",
                "prompt": "49"
            },
            {
                "date": "2017-12-01",
                "prompt": "50"
            },
            {
                "date": "2017-12-02",
                "prompt": "W"
            },
            {
                "date": "2017-12-03",
                "prompt": "W"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "天气寒冷，多补水，选用滋润保湿型化妆品，使用润唇膏。",
                    "level": "3",
                    "name": "化妆指数",
                    "status": "保湿"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒极易发生，避免去人群密集的场所，勤洗手勤通风有利于降低感冒几率。",
                    "level": "5",
                    "name": "感冒指数",
                    "status": "极易发"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "洗车后，可至少保持4天车辆清洁，非常适宜洗车。",
                    "level": "1",
                    "name": "洗车指数",
                    "status": "非常适宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "易感人群应适当减少室外活动。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "中"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "天气偏凉，可以穿上最时尚的那件大衣来凹造型，搭一条围巾时尚指数爆表。",
                    "level": "9",
                    "name": "穿衣指数",
                    "status": "凉"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "辐射较弱，涂擦SPF12-15、PA+护肤品。",
                    "level": "2",
                    "name": "紫外线指数",
                    "status": "弱"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "气温过低，特别容易着凉感冒，较不适宜户外运动，建议室内运动。",
                    "level": "11",
                    "name": "运动指数",
                    "status": "不适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "气压小幅波动，可能会影响鱼儿进食。",
                    "level": "2",
                    "name": "钓鱼指数",
                    "status": "较适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 0,
            "timestamp": 1510356603000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
