{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "秀英区",
            "co": "9",
            "coC": "0.9",
            "no2": "11",
            "no2C": "22.0",
            "o3": "42",
            "o3C": "133.0",
            "pm10": "62",
            "pm10C": "74.0",
            "pm25": "61",
            "pm25C": "44.0",
            "pubtime": "1511949600000",
            "rank": "292/606",
            "so2": "3",
            "so2C": "10.0",
            "value": "62"
        },
        "aqiForecast": [
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 00:00:00",
                "value": 49
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-29 17:00:00",
                "value": 67
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-29 18:00:00",
                "value": 56
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-29 18:00:00",
                "value": 51
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-29 18:00:00",
                "value": 41
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-29 18:00:00",
                "value": 44
            },
            {
                "date": "2017-12-04",
                "publishTime": "2017-11-29 18:00:00",
                "value": 38
            }
        ],
        "city": {
            "cityId": 285181,
            "counname": "中国",
            "name": "秀英区",
            "pname": "海南省",
            "timezone": "8"
        },
        "condition": {
            "condition": "雾",
            "conditionId": "26",
            "humidity": "94",
            "icon": "32",
            "pressure": "1014",
            "realFeel": "25",
            "sunRise": "2017-11-29 06:56:00",
            "sunSet": "2017-11-29 17:58:00",
            "temp": "21",
            "tips": "明天有雨，冷热适宜，感觉很舒适。",
            "updatetime": "2017-11-29 19:00:00",
            "uvi": "0",
            "windDir": "东北风",
            "windLevel": "2",
            "windSpeed": "2.45"
        },
        "forecast": [
            {
                "conditionDay": "阵雨",
                "conditionIdDay": "3",
                "conditionIdNight": "33",
                "conditionNight": "阵雨",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 14:01:00",
                "moonset": "2017-11-29 02:12:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 06:55:00",
                "sunset": "2017-11-28 17:58:00",
                "tempDay": "24",
                "tempNight": "20",
                "updatetime": "2017-11-28 23:13:00",
                "windDirDay": "东风",
                "windDirNight": "东风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "阵雨",
                "conditionIdDay": "3",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 14:42:00",
                "moonset": "2017-11-30 03:08:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 06:56:00",
                "sunset": "2017-11-29 17:58:00",
                "tempDay": "24",
                "tempNight": "21",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东风",
                "windDirNight": "东北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "阵雨",
                "conditionIdDay": "3",
                "conditionIdNight": "33",
                "conditionNight": "阵雨",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 15:25:00",
                "moonset": "2017-12-01 04:06:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 06:57:00",
                "sunset": "2017-11-30 17:58:00",
                "tempDay": "25",
                "tempNight": "20",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东北风",
                "windDirNight": "东北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "阵雨",
                "conditionIdDay": "3",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 16:09:00",
                "moonset": "2017-12-02 05:07:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 06:57:00",
                "sunset": "2017-12-01 17:58:00",
                "tempDay": "21",
                "tempNight": "19",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东北风",
                "windDirNight": "东北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 16:58:00",
                "moonset": "2017-12-03 06:11:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 06:58:00",
                "sunset": "2017-12-02 17:58:00",
                "tempDay": "22",
                "tempNight": "19",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东北风",
                "windDirNight": "东北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Full",
                "moonrise": "2017-12-03 17:52:00",
                "moonset": "2017-12-04 07:17:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 06:58:00",
                "sunset": "2017-12-03 17:58:00",
                "tempDay": "23",
                "tempNight": "19",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东北风",
                "windDirNight": "东北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "33",
                "conditionNight": "阵雨",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-04 18:50:00",
                "moonset": "2017-12-05 08:22:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 06:59:00",
                "sunset": "2017-12-04 17:59:00",
                "tempDay": "22",
                "tempNight": "19",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东北风",
                "windDirNight": "东北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "阵雨",
                "conditionIdDay": "3",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-05 19:52:00",
                "moonset": "2017-12-06 09:25:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 07:00:00",
                "sunset": "2017-12-05 17:59:00",
                "tempDay": "22",
                "tempNight": "19",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东北风",
                "windDirNight": "东北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 20:55:00",
                "moonset": "2017-12-07 10:23:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 07:00:00",
                "sunset": "2017-12-06 17:59:00",
                "tempDay": "21",
                "tempNight": "17",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东北风",
                "windDirNight": "南风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 21:59:00",
                "moonset": "2017-12-08 11:17:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 07:01:00",
                "sunset": "2017-12-07 17:59:00",
                "tempDay": "21",
                "tempNight": "16",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "西南风",
                "windDirNight": "西南风",
                "windLevelDay": "3-4",
                "windLevelNight": "3",
                "windSpeedDay": "6.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-08 23:00:00",
                "moonset": "2017-12-08 11:17:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 07:02:00",
                "sunset": "2017-12-08 18:00:00",
                "tempDay": "21",
                "tempNight": "16",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "西南风",
                "windDirNight": "西北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-11-30 23:58:00",
                "moonset": "2017-11-30 12:05:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 07:02:00",
                "sunset": "2017-12-09 18:00:00",
                "tempDay": "20",
                "tempNight": "15",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "西北风",
                "windDirNight": "北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Last",
                "moonrise": "None",
                "moonset": "2017-12-02 12:48:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 07:03:00",
                "sunset": "2017-12-10 18:00:00",
                "tempDay": "19",
                "tempNight": "15",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "西风",
                "windDirNight": "西南风",
                "windLevelDay": "3-4",
                "windLevelNight": "4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "8",
                "conditionNight": "雨",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-11 00:54:00",
                "moonset": "2017-12-11 13:29:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 07:03:00",
                "sunset": "2017-12-11 18:00:00",
                "tempDay": "20",
                "tempNight": "16",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "东北风",
                "windDirNight": "西南风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-03 01:47:00",
                "moonset": "2017-12-03 14:08:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 07:04:00",
                "sunset": "2017-12-12 18:01:00",
                "tempDay": "21",
                "tempNight": "18",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "西风",
                "windDirNight": "西北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3",
                "windSpeedDay": "6.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-04 02:39:00",
                "moonset": "2017-12-04 14:46:00",
                "predictDate": "2017-12-13",
                "sunrise": "2017-12-13 07:05:00",
                "sunset": "2017-12-13 18:01:00",
                "tempDay": "22",
                "tempNight": "18",
                "updatetime": "2017-11-29 18:14:00",
                "windDirDay": "西北风",
                "windDirNight": "西北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3",
                "windSpeedDay": "6.0",
                "windSpeedNight": "5.0"
            }
        ],
        "hourly": [
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "17",
                "humidity": "87",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "16"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "18",
                "humidity": "89",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "14"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "90",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "14"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "91",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "93",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "94",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "95",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "21",
                "uvi": "0",
                "windDir": "E",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "96",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "20",
                "uvi": "0",
                "windDir": "E",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "1",
                "humidity": "97",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "20",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "2",
                "humidity": "95",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "20",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "3",
                "humidity": "95",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "4",
                "humidity": "94",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "5",
                "humidity": "94",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "6",
                "humidity": "96",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "23",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "7",
                "humidity": "97",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "25",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "12"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "8",
                "humidity": "95",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "26",
                "temp": "21",
                "uvi": "1",
                "windDir": "ENE",
                "windSpeed": "14"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "9",
                "humidity": "92",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "27",
                "temp": "22",
                "uvi": "2",
                "windDir": "ENE",
                "windSpeed": "16"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "10",
                "humidity": "87",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "27",
                "temp": "22",
                "uvi": "3",
                "windDir": "ENE",
                "windSpeed": "16"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "11",
                "humidity": "82",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "29",
                "temp": "23",
                "uvi": "3",
                "windDir": "ENE",
                "windSpeed": "18"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "12",
                "humidity": "79",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "27",
                "temp": "25",
                "uvi": "3",
                "windDir": "ENE",
                "windSpeed": "18"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "13",
                "humidity": "76",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "28",
                "temp": "25",
                "uvi": "3",
                "windDir": "ENE",
                "windSpeed": "20"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "14",
                "humidity": "76",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "28",
                "temp": "25",
                "uvi": "3",
                "windDir": "ENE",
                "windSpeed": "20"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "15",
                "humidity": "78",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "27",
                "temp": "24",
                "uvi": "2",
                "windDir": "ENE",
                "windSpeed": "20"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "16",
                "humidity": "80",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "26",
                "temp": "23",
                "uvi": "1",
                "windDir": "ENE",
                "windSpeed": "20"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "17",
                "humidity": "85",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "23",
                "temp": "22",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "20"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "18",
                "humidity": "88",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "24",
                "temp": "21",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "18"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "建议用露质面霜打底，水质无油粉底霜，透明粉饼，粉质胭脂。",
                    "level": "10",
                    "name": "化妆指数",
                    "status": "控油"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒可能发生，体质较弱的童鞋们要注意了，要及时增减衣物，适时补充水分，坚持锻炼身体。",
                    "level": "2",
                    "name": "感冒指数",
                    "status": "可能"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "雨(雪)水和泥水会弄脏您的爱车，不适宜清洗车辆。",
                    "level": "10",
                    "name": "洗车指数",
                    "status": "不宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "气象条件有利于空气污染物扩散。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "良"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "温度适中，换季装扮。",
                    "level": "7",
                    "name": "穿衣指数",
                    "status": "舒适"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "辐射较弱，涂擦SPF12-15、PA+护肤品。",
                    "level": "2",
                    "name": "紫外线指数",
                    "status": "弱"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "受到阵雨天气的影响，不宜在户外运动。",
                    "level": "31",
                    "name": "运动指数",
                    "status": "不适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "天气又冷又在下雨，不宜出竿。",
                    "level": "18",
                    "name": "钓鱼指数",
                    "status": "不适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 18,
            "timestamp": 1510356543000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
