{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "水磨沟区",
            "co": "18",
            "coC": "1.8",
            "no2": "25",
            "no2C": "49.0",
            "o3": "5",
            "o3C": "17.0",
            "pm25": "126",
            "pm25C": "96.0",
            "pubtime": "1511895600000",
            "rank": "512/591",
            "so2": "5",
            "so2C": "14.0",
            "value": "127"
        },
        "aqiForecast": [
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 00:00:00",
                "value": 173
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-29 01:00:00",
                "value": 132
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-29 01:00:00",
                "value": 76
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-29 01:00:00",
                "value": 81
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-29 01:00:00",
                "value": 75
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-29 01:00:00",
                "value": 77
            },
            {
                "date": "2017-12-04",
                "publishTime": "2017-11-29 01:00:00",
                "value": 74
            }
        ],
        "city": {
            "cityId": 285313,
            "counname": "中国",
            "name": "水磨沟区",
            "pname": "新疆维吾尔自治区",
            "timezone": "8"
        },
        "condition": {
            "condition": "晴",
            "conditionId": "1",
            "humidity": "87",
            "icon": "30",
            "pressure": "1031",
            "realFeel": "-2",
            "sunRise": "2017-11-29 09:21:00",
            "sunSet": "2017-11-29 18:34:00",
            "temp": "-1",
            "tips": "天气阴冷，穿暖和点吧！",
            "updatetime": "2017-11-29 04:00:00",
            "uvi": "0",
            "windDir": "静风",
            "windLevel": "0",
            "windSpeed": "0.1"
        },
        "forecast": [
            {
                "conditionDay": "小雪",
                "conditionIdDay": "14",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 15:46:00",
                "moonset": "2017-11-29 03:40:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 09:19:00",
                "sunset": "2017-11-28 18:35:00",
                "tempDay": "0",
                "tempNight": "-4",
                "updatetime": "2017-11-28 23:10:00",
                "windDirDay": "西北风",
                "windDirNight": "北风",
                "windLevelDay": "3-4",
                "windLevelNight": "1",
                "windSpeedDay": "6.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 16:15:00",
                "moonset": "2017-11-29 03:40:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 09:21:00",
                "sunset": "2017-11-29 18:34:00",
                "tempDay": "0",
                "tempNight": "-5",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 16:46:00",
                "moonset": "2017-11-30 04:47:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 09:22:00",
                "sunset": "2017-11-30 18:34:00",
                "tempDay": "1",
                "tempNight": "-6",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 17:20:00",
                "moonset": "2017-12-01 05:58:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 09:23:00",
                "sunset": "2017-12-01 18:33:00",
                "tempDay": "0",
                "tempNight": "-6",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 17:58:00",
                "moonset": "2017-12-02 07:12:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 09:24:00",
                "sunset": "2017-12-02 18:33:00",
                "tempDay": "0",
                "tempNight": "-5",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "Full",
                "moonrise": "2017-12-03 18:41:00",
                "moonset": "2017-12-03 08:26:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 09:25:00",
                "sunset": "2017-12-03 18:33:00",
                "tempDay": "0",
                "tempNight": "-6",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-04 19:33:00",
                "moonset": "2017-12-04 09:41:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 09:26:00",
                "sunset": "2017-12-04 18:33:00",
                "tempDay": "0",
                "tempNight": "-7",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-05 20:33:00",
                "moonset": "2017-12-05 10:50:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 09:27:00",
                "sunset": "2017-12-05 18:32:00",
                "tempDay": "0",
                "tempNight": "-7",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "微风",
                "windDirNight": "东南风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 21:39:00",
                "moonset": "2017-12-06 11:52:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 09:28:00",
                "sunset": "2017-12-06 18:32:00",
                "tempDay": "0",
                "tempNight": "-6",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东南风",
                "windDirNight": "东南风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 22:49:00",
                "moonset": "2017-12-07 12:45:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 09:29:00",
                "sunset": "2017-12-07 18:32:00",
                "tempDay": "0",
                "tempNight": "-6",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东风",
                "windDirNight": "东南风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-11 00:00:00",
                "moonset": "2017-12-11 15:09:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 09:30:00",
                "sunset": "2017-12-08 18:32:00",
                "tempDay": "0",
                "tempNight": "-5",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东风",
                "windDirNight": "东南风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "None",
                "moonset": "2017-12-09 14:07:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 09:31:00",
                "sunset": "2017-12-09 18:32:00",
                "tempDay": "0",
                "tempNight": "-5",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东南风",
                "windDirNight": "东南风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Last",
                "moonrise": "2017-12-10 01:09:00",
                "moonset": "2017-12-10 14:39:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 09:32:00",
                "sunset": "2017-12-10 18:32:00",
                "tempDay": "0",
                "tempNight": "-5",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东南风",
                "windDirNight": "南风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-11 02:15:00",
                "moonset": "2017-12-11 15:09:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 09:33:00",
                "sunset": "2017-12-11 18:32:00",
                "tempDay": "-1",
                "tempNight": "-6",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "西风",
                "windDirNight": "西风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-12 03:20:00",
                "moonset": "2017-12-12 15:37:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 09:34:00",
                "sunset": "2017-12-12 18:32:00",
                "tempDay": "-2",
                "tempNight": "-6",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东风",
                "windDirNight": "东南风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            }
        ],
        "hourly": [
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "2",
                "humidity": "48",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "3"
            },
            {
                "condition": "多云",
                "date": "2017-11-29",
                "hour": "3",
                "humidity": "50",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "3"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "4",
                "humidity": "48",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "5",
                "humidity": "45",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "6",
                "humidity": "43",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "7",
                "humidity": "43",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "8",
                "humidity": "44",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "-1",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "9",
                "humidity": "45",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "0",
                "temp": "-1",
                "uvi": "1",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "10",
                "humidity": "44",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "1",
                "temp": "-1",
                "uvi": "2",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "11",
                "humidity": "43",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "2",
                "temp": "0",
                "uvi": "2",
                "windDir": "NE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "12",
                "humidity": "40",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "3",
                "temp": "0",
                "uvi": "2",
                "windDir": "NE",
                "windSpeed": "5"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "13",
                "humidity": "39",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "3",
                "temp": "0",
                "uvi": "2",
                "windDir": "NNE",
                "windSpeed": "5"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "14",
                "humidity": "40",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "3",
                "temp": "0",
                "uvi": "2",
                "windDir": "NNE",
                "windSpeed": "5"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "15",
                "humidity": "42",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "2",
                "temp": "0",
                "uvi": "1",
                "windDir": "N",
                "windSpeed": "5"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "16",
                "humidity": "44",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "2",
                "temp": "0",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "5"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "17",
                "humidity": "55",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "0",
                "temp": "0",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "5"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "18",
                "humidity": "69",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "1",
                "temp": "0",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "5"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "70",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "1",
                "temp": "0",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "67",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "0",
                "temp": "0",
                "uvi": "0",
                "windDir": "S",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "61",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "0",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "53",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "46",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "44",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "1",
                "humidity": "40",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "2",
                "humidity": "39",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-2",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "3"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "3",
                "humidity": "36",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "-3",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "3"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "天气寒冷，多补水，选用滋润保湿型化妆品，使用润唇膏。",
                    "level": "3",
                    "name": "化妆指数",
                    "status": "保湿"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒可能发生，体质较弱的童鞋们要注意了，要及时增减衣物，适时补充水分，坚持锻炼身体。",
                    "level": "2",
                    "name": "感冒指数",
                    "status": "可能"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "天气太过寒冷，洗车后汽车表面容易结冰，不宜洗车。",
                    "level": "10",
                    "name": "洗车指数",
                    "status": "不宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "易感人群应适当减少室外活动。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "中"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "天气偏凉，可以穿上最时尚的那件大衣来凹造型，搭一条围巾时尚指数爆表。",
                    "level": "9",
                    "name": "穿衣指数",
                    "status": "凉"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "辐射较弱，涂擦SPF12-15、PA+护肤品。",
                    "level": "2",
                    "name": "紫外线指数",
                    "status": "弱"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "空气轻度污染，不宜在户外运动。",
                    "level": "17",
                    "name": "运动指数",
                    "status": "不适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "气压小幅波动，可能会影响鱼儿进食。",
                    "level": "2",
                    "name": "钓鱼指数",
                    "status": "较适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 30,
            "timestamp": 1510356543000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
