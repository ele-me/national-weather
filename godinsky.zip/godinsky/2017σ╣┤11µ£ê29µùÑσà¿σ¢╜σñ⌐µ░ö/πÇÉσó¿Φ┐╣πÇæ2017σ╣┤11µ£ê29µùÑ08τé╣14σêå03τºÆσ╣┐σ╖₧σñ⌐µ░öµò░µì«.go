{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "越秀区",
            "co": "13",
            "coC": "1.3",
            "no2": "25",
            "no2C": "50.0",
            "o3": "1",
            "o3C": "3.0",
            "pm10": "60",
            "pm10C": "69.0",
            "pm25": "60",
            "pm25C": "43.0",
            "pubtime": "1511910000000",
            "rank": "300/578",
            "so2": "5",
            "so2C": "15.0",
            "value": "60"
        },
        "aqiForecast": [
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 00:00:00",
                "value": 59
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-29 06:00:00",
                "value": 61
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-29 06:00:00",
                "value": 62
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-29 06:00:00",
                "value": 56
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-29 06:00:00",
                "value": 46
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-29 06:00:00",
                "value": 45
            },
            {
                "date": "2017-12-04",
                "publishTime": "2017-11-29 06:00:00",
                "value": 49
            }
        ],
        "city": {
            "cityId": 285119,
            "counname": "中国",
            "name": "越秀区",
            "pname": "广东省",
            "timezone": "8"
        },
        "condition": {
            "condition": "晴",
            "conditionId": "1",
            "humidity": "90",
            "icon": "0",
            "pressure": "1018",
            "realFeel": "22",
            "sunRise": "2017-11-29 06:50:00",
            "sunSet": "2017-11-29 17:40:00",
            "temp": "18",
            "tips": "冷热适宜，感觉很舒适。",
            "updatetime": "2017-11-29 08:00:00",
            "uvi": "0",
            "windDir": "静风",
            "windLevel": "0",
            "windSpeed": "0.1"
        },
        "forecast": [
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 13:50:00",
                "moonset": "2017-11-29 01:59:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 06:49:00",
                "sunset": "2017-11-28 17:40:00",
                "tempDay": "25",
                "tempNight": "16",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "7",
                "conditionNight": "小雨",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 14:29:00",
                "moonset": "2017-11-30 02:56:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 06:50:00",
                "sunset": "2017-11-29 17:40:00",
                "tempDay": "25",
                "tempNight": "17",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "小雨",
                "conditionIdDay": "7",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 15:11:00",
                "moonset": "2017-12-01 03:55:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 06:50:00",
                "sunset": "2017-11-30 17:40:00",
                "tempDay": "21",
                "tempNight": "14",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4",
                "windLevelNight": "4",
                "windSpeedDay": "7.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 15:55:00",
                "moonset": "2017-12-02 04:58:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 06:51:00",
                "sunset": "2017-12-01 17:41:00",
                "tempDay": "18",
                "tempNight": "13",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4",
                "windLevelNight": "4",
                "windSpeedDay": "7.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 16:42:00",
                "moonset": "2017-12-03 06:03:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 06:52:00",
                "sunset": "2017-12-02 17:41:00",
                "tempDay": "19",
                "tempNight": "13",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Full",
                "moonrise": "2017-12-03 17:35:00",
                "moonset": "2017-12-04 07:09:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 06:52:00",
                "sunset": "2017-12-03 17:41:00",
                "tempDay": "22",
                "tempNight": "14",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-04 18:32:00",
                "moonset": "2017-12-05 08:15:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 06:53:00",
                "sunset": "2017-12-04 17:41:00",
                "tempDay": "21",
                "tempNight": "14",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-05 19:34:00",
                "moonset": "2017-12-06 09:18:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 06:54:00",
                "sunset": "2017-12-05 17:41:00",
                "tempDay": "19",
                "tempNight": "9",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "微风",
                "windDirNight": "西风",
                "windLevelDay": "4",
                "windLevelNight": "4",
                "windSpeedDay": "7.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 20:37:00",
                "moonset": "2017-12-07 10:16:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 06:54:00",
                "sunset": "2017-12-06 17:41:00",
                "tempDay": "20",
                "tempNight": "11",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "8",
                "conditionNight": "雨",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 21:42:00",
                "moonset": "2017-12-08 11:09:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 06:55:00",
                "sunset": "2017-12-07 17:41:00",
                "tempDay": "21",
                "tempNight": "12",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "东北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-08 22:44:00",
                "moonset": "2017-12-09 11:55:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 06:56:00",
                "sunset": "2017-12-08 17:42:00",
                "tempDay": "21",
                "tempNight": "13",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-09 23:44:00",
                "moonset": "2017-12-10 12:38:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 06:56:00",
                "sunset": "2017-12-09 17:42:00",
                "tempDay": "24",
                "tempNight": "7",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Last",
                "moonrise": "None",
                "moonset": "2017-12-10 12:38:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 06:57:00",
                "sunset": "2017-12-10 17:42:00",
                "tempDay": "15",
                "tempNight": "2",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3",
                "windSpeedDay": "6.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-11 00:40:00",
                "moonset": "2017-12-11 13:18:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 06:58:00",
                "sunset": "2017-12-11 17:42:00",
                "tempDay": "13",
                "tempNight": "2",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "东北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-12 01:35:00",
                "moonset": "2017-12-12 13:55:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 06:58:00",
                "sunset": "2017-12-12 17:43:00",
                "tempDay": "16",
                "tempNight": "2",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "东北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-13 02:27:00",
                "moonset": "2017-12-13 14:32:00",
                "predictDate": "2017-12-13",
                "sunrise": "2017-12-13 06:59:00",
                "sunset": "2017-12-13 17:43:00",
                "tempDay": "21",
                "tempNight": "5",
                "updatetime": "2017-11-29 07:10:08",
                "windDirDay": "东北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "2",
                "windSpeedDay": "5.0",
                "windSpeedNight": "3.0"
            }
        ],
        "hourly": [
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "6",
                "humidity": "85",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "21",
                "temp": "18",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "7",
                "humidity": "89",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "22",
                "temp": "18",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "8",
                "humidity": "89",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "22",
                "temp": "18",
                "uvi": "1",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "9",
                "humidity": "83",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "24",
                "temp": "19",
                "uvi": "2",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "10",
                "humidity": "75",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "26",
                "temp": "20",
                "uvi": "3",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "11",
                "humidity": "68",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "28",
                "temp": "21",
                "uvi": "4",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "12",
                "humidity": "62",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "28",
                "temp": "22",
                "uvi": "4",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "13",
                "humidity": "59",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "27",
                "temp": "23",
                "uvi": "2",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "14",
                "humidity": "57",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "28",
                "temp": "25",
                "uvi": "2",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "15",
                "humidity": "61",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "28",
                "temp": "25",
                "uvi": "2",
                "windDir": "NNW",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "16",
                "humidity": "65",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "27",
                "temp": "23",
                "uvi": "1",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "17",
                "humidity": "70",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "26",
                "temp": "22",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "5"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "18",
                "humidity": "74",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "25",
                "temp": "21",
                "uvi": "0",
                "windDir": "WNW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "77",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "21",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "79",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "20",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "78",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "76",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "74",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "NW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "75",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "22",
                "temp": "19",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "1",
                "humidity": "75",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "22",
                "temp": "19",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "2",
                "humidity": "75",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "22",
                "temp": "19",
                "uvi": "0",
                "windDir": "NNW",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "3",
                "humidity": "74",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "21",
                "temp": "19",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "4",
                "humidity": "74",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "21",
                "temp": "18",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "7"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "5",
                "humidity": "74",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "20",
                "temp": "18",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "6",
                "humidity": "75",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "20",
                "temp": "18",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "7",
                "humidity": "76",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "19",
                "temp": "18",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "11"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "建议用露质面霜打底，水质无油粉底霜，透明粉饼，粉质胭脂。",
                    "level": "10",
                    "name": "化妆指数",
                    "status": "控油"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒容易发生，少去人群密集的场所有利于降低感冒的几率。",
                    "level": "4",
                    "name": "感冒指数",
                    "status": "易发"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "雨(雪)水和泥水会弄脏您的爱车，不适宜清洗车辆。",
                    "level": "10",
                    "name": "洗车指数",
                    "status": "不宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "气象条件有利于空气污染物扩散。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "良"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "天气较热，衣物精干简洁，室内酌情添加空调衫。",
                    "level": "3",
                    "name": "穿衣指数",
                    "status": "热"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "辐射弱，涂擦SPF8-12防晒护肤品。",
                    "level": "1",
                    "name": "紫外线指数",
                    "status": "最弱"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "天气较好，且紫外线辐射不强，适宜户外运动。",
                    "level": "1",
                    "name": "运动指数",
                    "status": "适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "气压小幅波动，可能会影响鱼儿的进食。",
                    "level": "8",
                    "name": "钓鱼指数",
                    "status": "较适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 0,
            "timestamp": 1510356543000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
