{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "黄浦区",
            "co": "13",
            "coC": "1.3",
            "no2": "38",
            "no2C": "76.0",
            "o3": "17",
            "o3C": "54.0",
            "pm25": "196",
            "pm25C": "147.0",
            "pubtime": "1511899200000",
            "rank": "564/580",
            "so2": "6",
            "so2C": "17.0",
            "value": "196"
        },
        "aqiForecast": [
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 00:00:00",
                "value": 79
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-29 03:00:00",
                "value": 183
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-29 03:00:00",
                "value": 67
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-29 03:00:00",
                "value": 68
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-29 03:00:00",
                "value": 54
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-29 03:00:00",
                "value": 45
            },
            {
                "date": "2017-12-04",
                "publishTime": "2017-11-29 03:00:00",
                "value": 50
            }
        ],
        "city": {
            "cityId": 284826,
            "counname": "中国",
            "name": "黄浦区",
            "pname": "上海市",
            "timezone": "8"
        },
        "condition": {
            "condition": "晴",
            "conditionId": "1",
            "humidity": "80",
            "icon": "30",
            "pressure": "1024",
            "realFeel": "17",
            "sunRise": "2017-11-29 06:33:00",
            "sunSet": "2017-11-29 16:51:00",
            "temp": "13",
            "tips": "今天有雨，略微偏凉，还是蛮舒适的。",
            "updatetime": "2017-11-29 05:00:00",
            "uvi": "0",
            "windDir": "静风",
            "windLevel": "0",
            "windSpeed": "0.1"
        },
        "forecast": [
            {
                "conditionDay": "小雨",
                "conditionIdDay": "7",
                "conditionIdNight": "7",
                "conditionNight": "小雨",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 13:20:00",
                "moonset": "2017-11-29 01:22:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 06:32:00",
                "sunset": "2017-11-28 16:52:00",
                "tempDay": "19",
                "tempNight": "12",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "西南风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "1",
                "windSpeedDay": "3.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "小雨",
                "conditionIdDay": "7",
                "conditionIdNight": "7",
                "conditionNight": "小雨",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 13:56:00",
                "moonset": "2017-11-30 02:23:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 06:33:00",
                "sunset": "2017-11-29 16:51:00",
                "tempDay": "14",
                "tempNight": "9",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东北风",
                "windDirNight": "北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 14:34:00",
                "moonset": "2017-12-01 03:26:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 06:34:00",
                "sunset": "2017-11-30 16:51:00",
                "tempDay": "11",
                "tempNight": "8",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4",
                "windLevelNight": "4",
                "windSpeedDay": "7.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 15:14:00",
                "moonset": "2017-12-02 04:32:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 06:34:00",
                "sunset": "2017-12-01 16:51:00",
                "tempDay": "12",
                "tempNight": "8",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "东北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 15:58:00",
                "moonset": "2017-12-03 05:41:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 06:35:00",
                "sunset": "2017-12-02 16:51:00",
                "tempDay": "14",
                "tempNight": "8",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东北风",
                "windDirNight": "东北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "小雨",
                "conditionIdDay": "7",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "Full",
                "moonrise": "2017-12-03 16:48:00",
                "moonset": "2017-12-04 06:49:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 06:36:00",
                "sunset": "2017-12-03 16:51:00",
                "tempDay": "14",
                "tempNight": "10",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "小雨",
                "conditionIdDay": "7",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-04 17:43:00",
                "moonset": "2017-12-05 07:57:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 06:37:00",
                "sunset": "2017-12-04 16:51:00",
                "tempDay": "13",
                "tempNight": "6",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3-4",
                "windLevelNight": "4-5",
                "windSpeedDay": "6.0",
                "windSpeedNight": "9.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-05 18:43:00",
                "moonset": "2017-12-06 08:59:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 06:38:00",
                "sunset": "2017-12-05 16:51:00",
                "tempDay": "11",
                "tempNight": "2",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "西北风",
                "windDirNight": "西北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 19:48:00",
                "moonset": "2017-12-07 09:56:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 06:38:00",
                "sunset": "2017-12-06 16:51:00",
                "tempDay": "8",
                "tempNight": "3",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "西北风",
                "windDirNight": "东风",
                "windLevelDay": "3-4",
                "windLevelNight": "3",
                "windSpeedDay": "6.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 20:54:00",
                "moonset": "2017-12-08 10:46:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 06:39:00",
                "sunset": "2017-12-07 16:51:00",
                "tempDay": "12",
                "tempNight": "5",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东南风",
                "windDirNight": "南风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-08 21:59:00",
                "moonset": "2017-12-09 11:31:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 06:40:00",
                "sunset": "2017-12-08 16:51:00",
                "tempDay": "13",
                "tempNight": "7",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "南风",
                "windDirNight": "西北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-09 23:02:00",
                "moonset": "2017-12-10 12:10:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 06:41:00",
                "sunset": "2017-12-09 16:52:00",
                "tempDay": "12",
                "tempNight": "4",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4-5",
                "windLevelNight": "3-4",
                "windSpeedDay": "9.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "8",
                "conditionNight": "雨",
                "moonphase": "Last",
                "moonrise": "None",
                "moonset": "2017-12-10 12:10:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 06:41:00",
                "sunset": "2017-12-10 16:52:00",
                "tempDay": "7",
                "tempNight": "4",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "北风",
                "windDirNight": "东北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3",
                "windSpeedDay": "6.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "8",
                "conditionNight": "雨",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-11 00:02:00",
                "moonset": "2017-12-11 12:46:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 06:42:00",
                "sunset": "2017-12-11 16:52:00",
                "tempDay": "8",
                "tempNight": "5",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东风",
                "windDirNight": "东北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "雨",
                "conditionIdDay": "8",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-12 01:00:00",
                "moonset": "2017-12-12 13:21:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 06:43:00",
                "sunset": "2017-12-12 16:52:00",
                "tempDay": "11",
                "tempNight": "8",
                "updatetime": "2017-11-28 23:10:08",
                "windDirDay": "东风",
                "windDirNight": "东风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            }
        ],
        "hourly": [
            {
                "condition": "雾",
                "date": "2017-11-29",
                "hour": "3",
                "humidity": "79",
                "iconDay": "18",
                "iconNight": "32",
                "pressure": "0",
                "realFeel": "12",
                "temp": "14",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "12"
            },
            {
                "condition": "多云",
                "date": "2017-11-29",
                "hour": "4",
                "humidity": "81",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "11",
                "temp": "14",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "14"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "5",
                "humidity": "85",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "10",
                "temp": "14",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "16"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "6",
                "humidity": "84",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "11",
                "temp": "14",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "16"
            },
            {
                "condition": "雨",
                "date": "2017-11-29",
                "hour": "7",
                "humidity": "81",
                "iconDay": "8",
                "iconNight": "8",
                "pressure": "0",
                "realFeel": "11",
                "temp": "14",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "16"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "8",
                "humidity": "78",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "12",
                "temp": "14",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "16"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "9",
                "humidity": "73",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "12",
                "temp": "14",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "16"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "10",
                "humidity": "66",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "12",
                "temp": "14",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "18"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "11",
                "humidity": "65",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "12",
                "temp": "14",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "18"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "12",
                "humidity": "62",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "11",
                "temp": "14",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "18"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "13",
                "humidity": "67",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "9",
                "temp": "14",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "18"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "14",
                "humidity": "68",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "9",
                "temp": "14",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "18"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "15",
                "humidity": "68",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "9",
                "temp": "14",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "16",
                "humidity": "68",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "9",
                "temp": "12",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "17",
                "humidity": "67",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "7",
                "temp": "11",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "18",
                "humidity": "67",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "8",
                "temp": "10",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "66",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "7",
                "temp": "9",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "66",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "6",
                "temp": "9",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "68",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "5",
                "temp": "9",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "69",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "7",
                "temp": "9",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "71",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "6",
                "temp": "9",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "72",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "4",
                "temp": "9",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "22"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "1",
                "humidity": "72",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "4",
                "temp": "9",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "22"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "2",
                "humidity": "71",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "5",
                "temp": "8",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "22"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "3",
                "humidity": "71",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "5",
                "temp": "8",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "22"
            },
            {
                "condition": "阵雨",
                "date": "2017-11-30",
                "hour": "4",
                "humidity": "70",
                "iconDay": "3",
                "iconNight": "33",
                "pressure": "0",
                "realFeel": "3",
                "temp": "8",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "24"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "建议用露质面霜打底，水质无油粉底霜，透明粉饼，粉质胭脂。",
                    "level": "6",
                    "name": "化妆指数",
                    "status": "控油"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒极易发生，避免去人群密集的场所，勤洗手勤通风有利于降低感冒几率。",
                    "level": "5",
                    "name": "感冒指数",
                    "status": "极易发"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "雨(雪)水和泥水会弄脏您的爱车，不适宜清洗车辆。",
                    "level": "10",
                    "name": "洗车指数",
                    "status": "不宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "易感人群应适当减少室外活动。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "中"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "天气偏凉，可以穿上最时尚的那件大衣来凹造型，搭一条围巾时尚指数爆表。",
                    "level": "9",
                    "name": "穿衣指数",
                    "status": "凉"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "辐射弱，涂擦SPF8-12防晒护肤品。",
                    "level": "1",
                    "name": "紫外线指数",
                    "status": "最弱"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "空气轻度污染，不宜在户外运动。",
                    "level": "17",
                    "name": "运动指数",
                    "status": "不适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "天气又冷又在下雨，不宜出竿。",
                    "level": "18",
                    "name": "钓鱼指数",
                    "status": "不适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 0,
            "timestamp": 1510356543000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
