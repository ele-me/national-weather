{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "市南区",
            "co": "6",
            "coC": "0.6",
            "no2": "19",
            "no2C": "37.0",
            "o3": "12",
            "o3C": "38.0",
            "pm10": "93",
            "pm10C": "135.0",
            "pm25": "44",
            "pm25C": "31.0",
            "pubtime": "1511884800000",
            "rank": "417/604",
            "so2": "3",
            "so2C": "10.0",
            "value": "93"
        },
        "aqiForecast": [
            {
                "date": "2017-11-27",
                "publishTime": "2017-11-27 00:00:00",
                "value": 53
            },
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 23:00:00",
                "value": 100
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-28 23:00:00",
                "value": 85
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-28 23:00:00",
                "value": 67
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-28 23:00:00",
                "value": 61
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-28 23:00:00",
                "value": 63
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-28 23:00:00",
                "value": 64
            }
        ],
        "city": {
            "cityId": 284976,
            "counname": "中国",
            "name": "市南区",
            "pname": "山东省",
            "timezone": "8"
        },
        "condition": {
            "condition": "晴",
            "conditionId": "1",
            "humidity": "68",
            "icon": "30",
            "pressure": "1028",
            "realFeel": "0",
            "sunRise": "2017-11-29 06:48:00",
            "sunSet": "2017-11-29 16:45:00",
            "temp": "4",
            "tips": "风那么大，感觉更冷了。",
            "updatetime": "2017-11-29 01:00:00",
            "uvi": "0",
            "windDir": "北风",
            "windLevel": "5",
            "windSpeed": "9.35"
        },
        "forecast": [
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 13:28:00",
                "moonset": "2017-11-29 01:25:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 06:47:00",
                "sunset": "2017-11-28 16:45:00",
                "tempDay": "14",
                "tempNight": "2",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "南风",
                "windDirNight": "北风",
                "windLevelDay": "3-4",
                "windLevelNight": "5-6",
                "windSpeedDay": "6.0",
                "windSpeedNight": "11.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 14:01:00",
                "moonset": "2017-11-30 02:28:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 06:48:00",
                "sunset": "2017-11-29 16:45:00",
                "tempDay": "7",
                "tempNight": "-1",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4-5",
                "windLevelNight": "4-5",
                "windSpeedDay": "9.0",
                "windSpeedNight": "9.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 14:36:00",
                "moonset": "2017-12-01 03:34:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 06:49:00",
                "sunset": "2017-11-30 16:45:00",
                "tempDay": "4",
                "tempNight": "0",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 15:14:00",
                "moonset": "2017-12-02 04:43:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 06:50:00",
                "sunset": "2017-12-01 16:44:00",
                "tempDay": "6",
                "tempNight": "1",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "南风",
                "windDirNight": "南风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 15:56:00",
                "moonset": "2017-12-03 05:53:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 06:51:00",
                "sunset": "2017-12-02 16:44:00",
                "tempDay": "9",
                "tempNight": "5",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "南风",
                "windDirNight": "南风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Full",
                "moonrise": "2017-12-03 16:43:00",
                "moonset": "2017-12-04 07:04:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 06:52:00",
                "sunset": "2017-12-03 16:44:00",
                "tempDay": "11",
                "tempNight": "2",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4-5",
                "windLevelNight": "4-5",
                "windSpeedDay": "9.0",
                "windSpeedNight": "9.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-04 17:37:00",
                "moonset": "2017-12-05 08:12:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 06:53:00",
                "sunset": "2017-12-04 16:44:00",
                "tempDay": "6",
                "tempNight": "2",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4-5",
                "windLevelNight": "4-5",
                "windSpeedDay": "9.0",
                "windSpeedNight": "9.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-05 18:37:00",
                "moonset": "2017-12-06 09:15:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 06:54:00",
                "sunset": "2017-12-05 16:44:00",
                "tempDay": "8",
                "tempNight": "-1",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "北风",
                "windDirNight": "西北风",
                "windLevelDay": "4-5",
                "windLevelNight": "3",
                "windSpeedDay": "9.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 19:42:00",
                "moonset": "2017-12-07 10:10:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 06:54:00",
                "sunset": "2017-12-06 16:44:00",
                "tempDay": "6",
                "tempNight": "0",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "西风",
                "windDirNight": "东北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 20:49:00",
                "moonset": "2017-12-08 10:59:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 06:55:00",
                "sunset": "2017-12-07 16:44:00",
                "tempDay": "6",
                "tempNight": "1",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "西南风",
                "windDirNight": "西南风",
                "windLevelDay": "3-4",
                "windLevelNight": "3",
                "windSpeedDay": "6.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-08 21:56:00",
                "moonset": "2017-12-09 11:41:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 06:56:00",
                "sunset": "2017-12-08 16:44:00",
                "tempDay": "8",
                "tempNight": "0",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "西风",
                "windDirNight": "西北风",
                "windLevelDay": "5",
                "windLevelNight": "4",
                "windSpeedDay": "10.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-09 23:01:00",
                "moonset": "2017-12-10 12:18:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 06:57:00",
                "sunset": "2017-12-09 16:44:00",
                "tempDay": "4",
                "tempNight": "-2",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "西北风",
                "windDirNight": "西风",
                "windLevelDay": "3-4",
                "windLevelNight": "4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Last",
                "moonrise": "None",
                "moonset": "2017-12-10 12:18:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 06:58:00",
                "sunset": "2017-12-10 16:44:00",
                "tempDay": "3",
                "tempNight": "-2",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "西北风",
                "windDirNight": "西风",
                "windLevelDay": "3-4",
                "windLevelNight": "3",
                "windSpeedDay": "6.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-11 00:04:00",
                "moonset": "2017-12-11 12:52:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 06:59:00",
                "sunset": "2017-12-11 16:44:00",
                "tempDay": "4",
                "tempNight": "-1",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "西南风",
                "windDirNight": "西南风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-12 01:04:00",
                "moonset": "2017-12-12 13:25:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 06:59:00",
                "sunset": "2017-12-12 16:44:00",
                "tempDay": "7",
                "tempNight": "0",
                "updatetime": "2017-11-28 23:11:00",
                "windDirDay": "北风",
                "windDirNight": "西北风",
                "windLevelDay": "4",
                "windLevelNight": "4",
                "windSpeedDay": "7.0",
                "windSpeedNight": "7.0"
            }
        ],
        "hourly": [
            {
                "condition": "多云",
                "date": "2017-11-28",
                "hour": "23",
                "humidity": "45",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "1",
                "temp": "4",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "25"
            },
            {
                "condition": "多云",
                "date": "2017-11-29",
                "hour": "0",
                "humidity": "45",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "0",
                "temp": "5",
                "uvi": "0",
                "windDir": "N",
                "windSpeed": "24"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "1",
                "humidity": "46",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "3",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "24"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "2",
                "humidity": "48",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "2",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "24"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "3",
                "humidity": "49",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "2",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "24"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "4",
                "humidity": "51",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "1",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "24"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "5",
                "humidity": "52",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "0",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "24"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "6",
                "humidity": "52",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-4",
                "temp": "0",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "24"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "7",
                "humidity": "55",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-5",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NNE",
                "windSpeed": "22"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "8",
                "humidity": "49",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "9",
                "humidity": "45",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "0",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "10",
                "humidity": "42",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "1",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "11",
                "humidity": "40",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "2",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "12",
                "humidity": "38",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "1",
                "temp": "3",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "20"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "13",
                "humidity": "36",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "1",
                "temp": "4",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "18"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "14",
                "humidity": "36",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "2",
                "temp": "5",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "18"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "15",
                "humidity": "36",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "1",
                "temp": "4",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "16"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "16",
                "humidity": "35",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "1",
                "temp": "3",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "16"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "17",
                "humidity": "36",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "0",
                "temp": "2",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "16"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "18",
                "humidity": "37",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "16"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "39",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "0",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "14"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "41",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "0",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "14"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "42",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-1",
                "temp": "0",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "14"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "45",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "14"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "47",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "14"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "49",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "-1",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "14"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "天气寒冷，多补水，选用滋润保湿型化妆品，使用润唇膏。",
                    "level": "3",
                    "name": "化妆指数",
                    "status": "保湿"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒极易发生，避免去人群密集的场所，勤洗手勤通风有利于降低感冒几率。",
                    "level": "5",
                    "name": "感冒指数",
                    "status": "极易发"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "洗车后，可至少保持4天车辆清洁，非常适宜洗车。",
                    "level": "1",
                    "name": "洗车指数",
                    "status": "非常适宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "气象条件有利于空气污染物扩散。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "良"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "外面天寒地冻，防寒保暖最重要，帽子、围巾、手套全副武装，不宜室外逛街。",
                    "level": "11",
                    "name": "穿衣指数",
                    "status": "寒冷"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "辐射弱，涂擦SPF8-12防晒护肤品。",
                    "level": "1",
                    "name": "紫外线指数",
                    "status": "最弱"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "受到大风天气的影响，不宜在户外运动。",
                    "level": "14",
                    "name": "运动指数",
                    "status": "不适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "风太大了，不宜外出垂钓。",
                    "level": "17",
                    "name": "钓鱼指数",
                    "status": "不适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 0,
            "timestamp": 1510356603000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
