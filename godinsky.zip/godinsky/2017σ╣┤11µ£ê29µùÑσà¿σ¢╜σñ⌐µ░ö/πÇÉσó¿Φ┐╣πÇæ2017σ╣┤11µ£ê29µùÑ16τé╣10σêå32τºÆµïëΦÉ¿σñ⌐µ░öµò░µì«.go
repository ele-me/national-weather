{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "拉萨市城关区",
            "co": "6",
            "coC": "0.6",
            "no2": "6",
            "no2C": "12.0",
            "o3": "28",
            "o3C": "90.0",
            "pm10": "53",
            "pm10C": "55.0",
            "pm25": "33",
            "pm25C": "23.0",
            "pubtime": "1511938800000",
            "rank": "307/607",
            "so2": "2",
            "so2C": "6.0",
            "value": "53"
        },
        "aqiForecast": [
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 00:00:00",
                "value": 57
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-29 14:00:00",
                "value": 61
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-29 15:00:00",
                "value": 45
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-29 15:00:00",
                "value": 44
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-29 15:00:00",
                "value": 45
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-29 15:00:00",
                "value": 44
            },
            {
                "date": "2017-12-04",
                "publishTime": "2017-11-29 15:00:00",
                "value": 46
            }
        ],
        "city": {
            "cityId": 285258,
            "counname": "中国",
            "name": "拉萨市城关区",
            "pname": "西藏自治区",
            "timezone": "8"
        },
        "condition": {
            "condition": "晴",
            "conditionId": "1",
            "humidity": "15",
            "icon": "0",
            "pressure": "1017",
            "realFeel": "13",
            "sunRise": "2017-11-29 08:31:00",
            "sunSet": "2017-11-29 18:56:00",
            "temp": "7",
            "tips": "天冷了，该加衣服了！",
            "updatetime": "2017-11-29 16:00:00",
            "uvi": "2",
            "windDir": "西北风",
            "windLevel": "1",
            "windSpeed": "0.9"
        },
        "forecast": [
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 15:24:00",
                "moonset": "2017-11-28 02:31:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 08:30:00",
                "sunset": "2017-11-28 18:56:00",
                "tempDay": "11",
                "tempNight": "-5",
                "updatetime": "2017-11-28 23:10:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 16:01:00",
                "moonset": "2017-11-30 04:29:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 08:31:00",
                "sunset": "2017-11-29 18:56:00",
                "tempDay": "9",
                "tempNight": "-6",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 16:39:00",
                "moonset": "2017-12-01 05:32:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 08:32:00",
                "sunset": "2017-11-30 18:56:00",
                "tempDay": "8",
                "tempNight": "-6",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 17:21:00",
                "moonset": "2017-12-02 06:37:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 08:32:00",
                "sunset": "2017-12-01 18:56:00",
                "tempDay": "9",
                "tempNight": "-6",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 18:06:00",
                "moonset": "2017-12-03 07:45:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 08:33:00",
                "sunset": "2017-12-02 18:56:00",
                "tempDay": "11",
                "tempNight": "-5",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "Full",
                "moonrise": "2017-12-03 18:56:00",
                "moonset": "2017-12-04 08:53:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 08:34:00",
                "sunset": "2017-12-03 18:56:00",
                "tempDay": "11",
                "tempNight": "-6",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-04 19:52:00",
                "moonset": "2017-12-05 10:00:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 08:35:00",
                "sunset": "2017-12-04 18:56:00",
                "tempDay": "13",
                "tempNight": "-4",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-05 20:54:00",
                "moonset": "2017-12-06 11:03:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 08:36:00",
                "sunset": "2017-12-05 18:56:00",
                "tempDay": "16",
                "tempNight": "-4",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 21:58:00",
                "moonset": "2017-12-07 11:59:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 08:36:00",
                "sunset": "2017-12-06 18:56:00",
                "tempDay": "13",
                "tempNight": "1",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "西南风",
                "windDirNight": "西南风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 23:04:00",
                "moonset": "2017-12-08 12:49:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 08:37:00",
                "sunset": "2017-12-07 18:56:00",
                "tempDay": "13",
                "tempNight": "1",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "东北风",
                "windDirNight": "西南风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "None",
                "moonset": "2017-12-08 12:49:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 08:38:00",
                "sunset": "2017-12-08 18:56:00",
                "tempDay": "10",
                "tempNight": "-2",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "东北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-09 00:08:00",
                "moonset": "2017-12-09 13:34:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 08:38:00",
                "sunset": "2017-12-09 18:57:00",
                "tempDay": "8",
                "tempNight": "-2",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "东风",
                "windDirNight": "东风",
                "windLevelDay": "1",
                "windLevelNight": "2",
                "windSpeedDay": "1.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "30",
                "conditionNight": "晴",
                "moonphase": "Last",
                "moonrise": "2017-12-10 01:10:00",
                "moonset": "2017-12-10 14:13:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 08:39:00",
                "sunset": "2017-12-10 18:57:00",
                "tempDay": "8",
                "tempNight": "-1",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "西南风",
                "windDirNight": "东北风",
                "windLevelDay": "2",
                "windLevelNight": "1",
                "windSpeedDay": "3.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-11 02:09:00",
                "moonset": "2017-12-11 14:50:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 08:40:00",
                "sunset": "2017-12-11 18:57:00",
                "tempDay": "7",
                "tempNight": "-1",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "西风",
                "windDirNight": "南风",
                "windLevelDay": "1",
                "windLevelNight": "1",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-12 03:06:00",
                "moonset": "2017-12-12 15:25:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 08:41:00",
                "sunset": "2017-12-12 18:57:00",
                "tempDay": "8",
                "tempNight": "-1",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "西风",
                "windDirNight": "西南风",
                "windLevelDay": "4-5",
                "windLevelNight": "1",
                "windSpeedDay": "9.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-13 04:01:00",
                "moonset": "2017-12-13 15:59:00",
                "predictDate": "2017-12-13",
                "sunrise": "2017-12-13 08:41:00",
                "sunset": "2017-12-13 18:57:00",
                "tempDay": "8",
                "tempNight": "-1",
                "updatetime": "2017-11-29 15:11:00",
                "windDirDay": "西风",
                "windDirNight": "南风",
                "windLevelDay": "3-4",
                "windLevelNight": "1",
                "windSpeedDay": "6.0",
                "windSpeedNight": "1.0"
            }
        ],
        "hourly": [
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "14",
                "humidity": "17",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "8",
                "temp": "5",
                "uvi": "2",
                "windDir": "SSW",
                "windSpeed": "9"
            },
            {
                "condition": "多云",
                "date": "2017-11-29",
                "hour": "15",
                "humidity": "14",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "8",
                "temp": "7",
                "uvi": "1",
                "windDir": "SW",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "16",
                "humidity": "12",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "8",
                "temp": "9",
                "uvi": "1",
                "windDir": "WSW",
                "windSpeed": "11"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "17",
                "humidity": "12",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "7",
                "temp": "7",
                "uvi": "0",
                "windDir": "WSW",
                "windSpeed": "11"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "18",
                "humidity": "14",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "5",
                "temp": "5",
                "uvi": "0",
                "windDir": "SW",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "18",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "3",
                "temp": "3",
                "uvi": "0",
                "windDir": "SW",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "21",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "3",
                "temp": "2",
                "uvi": "0",
                "windDir": "S",
                "windSpeed": "5"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "24",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "0",
                "temp": "1",
                "uvi": "0",
                "windDir": "SSE",
                "windSpeed": "7"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "26",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-2",
                "temp": "0",
                "uvi": "0",
                "windDir": "SE",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "28",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-4",
                "temp": "0",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "32",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-4",
                "temp": "-1",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "1",
                "humidity": "37",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-5",
                "temp": "-2",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "7"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "2",
                "humidity": "41",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "-6",
                "temp": "-3",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "7"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "3",
                "humidity": "42",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-7",
                "temp": "-3",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "7"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "4",
                "humidity": "42",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-7",
                "temp": "-3",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "7"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "5",
                "humidity": "41",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-8",
                "temp": "-4",
                "uvi": "0",
                "windDir": "SE",
                "windSpeed": "7"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "6",
                "humidity": "44",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-8",
                "temp": "-4",
                "uvi": "0",
                "windDir": "SE",
                "windSpeed": "7"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "7",
                "humidity": "47",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-9",
                "temp": "-5",
                "uvi": "0",
                "windDir": "SE",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "8",
                "humidity": "51",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-9",
                "temp": "-6",
                "uvi": "1",
                "windDir": "SE",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "9",
                "humidity": "49",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-7",
                "temp": "-4",
                "uvi": "2",
                "windDir": "SE",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "10",
                "humidity": "36",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "-3",
                "temp": "-2",
                "uvi": "3",
                "windDir": "SE",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "11",
                "humidity": "23",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "3",
                "temp": "1",
                "uvi": "4",
                "windDir": "SE",
                "windSpeed": "11"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "12",
                "humidity": "17",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "7",
                "temp": "3",
                "uvi": "4",
                "windDir": "SE",
                "windSpeed": "11"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "13",
                "humidity": "12",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "8",
                "temp": "4",
                "uvi": "4",
                "windDir": "SSE",
                "windSpeed": "11"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "14",
                "humidity": "9",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "8",
                "temp": "5",
                "uvi": "2",
                "windDir": "SSE",
                "windSpeed": "11"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "15",
                "humidity": "7",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "8",
                "temp": "5",
                "uvi": "2",
                "windDir": "S",
                "windSpeed": "12"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "天气寒冷，多补水，选用滋润保湿型化妆品，使用润唇膏。",
                    "level": "3",
                    "name": "化妆指数",
                    "status": "保湿"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒极易发生，避免去人群密集的场所，勤洗手勤通风有利于降低感冒几率。",
                    "level": "5",
                    "name": "感冒指数",
                    "status": "极易发"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "洗车后，可至少保持4天车辆清洁，非常适宜洗车。",
                    "level": "1",
                    "name": "洗车指数",
                    "status": "非常适宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "易感人群应适当减少室外活动。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "中"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "天气偏凉，增加衣物厚度。",
                    "level": "8",
                    "name": "穿衣指数",
                    "status": "温凉"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "涂擦SPF大于15、PA+防晒护肤品。",
                    "level": "4",
                    "name": "紫外线指数",
                    "status": "强"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "气温过低，特别容易着凉感冒，较不适宜户外运动，建议室内运动。",
                    "level": "11",
                    "name": "运动指数",
                    "status": "不适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "温差稍大，鱼儿不太活跃，可能会对钓鱼产生影响。",
                    "level": "3",
                    "name": "钓鱼指数",
                    "status": "较适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 30,
            "timestamp": 1510356603000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
