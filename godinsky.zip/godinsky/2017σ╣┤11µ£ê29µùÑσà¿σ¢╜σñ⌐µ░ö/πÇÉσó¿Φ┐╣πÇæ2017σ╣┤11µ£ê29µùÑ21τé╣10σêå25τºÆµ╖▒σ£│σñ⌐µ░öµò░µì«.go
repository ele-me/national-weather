{
    "code": 0,
    "data": {
        "aqi": {
            "cityName": "福田区",
            "co": "10",
            "coC": "1.0",
            "no2": "39",
            "no2C": "77.0",
            "o3": "16",
            "o3C": "50.0",
            "pm10": "70",
            "pm10C": "89.0",
            "pm25": "74",
            "pm25C": "54.0",
            "pubtime": "1511956800000",
            "rank": "352/605",
            "so2": "3",
            "so2C": "8.0",
            "value": "74"
        },
        "aqiForecast": [
            {
                "date": "2017-11-28",
                "publishTime": "2017-11-28 00:00:00",
                "value": 63
            },
            {
                "date": "2017-11-29",
                "publishTime": "2017-11-29 19:00:00",
                "value": 65
            },
            {
                "date": "2017-11-30",
                "publishTime": "2017-11-29 20:00:00",
                "value": 36
            },
            {
                "date": "2017-12-01",
                "publishTime": "2017-11-29 20:00:00",
                "value": 40
            },
            {
                "date": "2017-12-02",
                "publishTime": "2017-11-29 20:00:00",
                "value": 50
            },
            {
                "date": "2017-12-03",
                "publishTime": "2017-11-29 20:00:00",
                "value": 44
            },
            {
                "date": "2017-12-04",
                "publishTime": "2017-11-29 20:00:00",
                "value": 40
            }
        ],
        "city": {
            "cityId": 285127,
            "counname": "中国",
            "name": "福田区",
            "pname": "广东省",
            "timezone": "8"
        },
        "condition": {
            "condition": "多云",
            "conditionId": "8",
            "humidity": "76",
            "icon": "31",
            "pressure": "1016",
            "realFeel": "27",
            "sunRise": "2017-11-29 06:45:00",
            "sunSet": "2017-11-29 17:38:00",
            "temp": "24",
            "tips": "略微偏热，注意衣物变化。",
            "updatetime": "2017-11-29 21:00:00",
            "uvi": "0",
            "windDir": "静风",
            "windLevel": "0",
            "windSpeed": "0.1"
        },
        "forecast": [
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-28 13:47:00",
                "moonset": "2017-11-29 01:56:00",
                "predictDate": "2017-11-28",
                "sunrise": "2017-11-28 06:45:00",
                "sunset": "2017-11-28 17:38:00",
                "tempDay": "27",
                "tempNight": "19",
                "updatetime": "2017-11-28 23:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-29 14:26:00",
                "moonset": "2017-11-30 02:52:00",
                "predictDate": "2017-11-29",
                "sunrise": "2017-11-29 06:45:00",
                "sunset": "2017-11-29 17:38:00",
                "tempDay": "29",
                "tempNight": "19",
                "updatetime": "2017-11-29 20:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "0",
                "windLevelNight": "0",
                "windSpeedDay": "1.0",
                "windSpeedNight": "1.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-11-30 15:08:00",
                "moonset": "2017-12-01 03:52:00",
                "predictDate": "2017-11-30",
                "sunrise": "2017-11-30 06:46:00",
                "sunset": "2017-11-30 17:38:00",
                "tempDay": "25",
                "tempNight": "16",
                "updatetime": "2017-11-29 20:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-01 15:52:00",
                "moonset": "2017-12-02 04:54:00",
                "predictDate": "2017-12-01",
                "sunrise": "2017-12-01 06:47:00",
                "sunset": "2017-12-01 17:38:00",
                "tempDay": "22",
                "tempNight": "15",
                "updatetime": "2017-11-29 20:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaxingGibbous",
                "moonrise": "2017-12-02 16:40:00",
                "moonset": "2017-12-03 05:59:00",
                "predictDate": "2017-12-02",
                "sunrise": "2017-12-02 06:47:00",
                "sunset": "2017-12-02 17:39:00",
                "tempDay": "23",
                "tempNight": "15",
                "updatetime": "2017-11-29 20:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Full",
                "moonrise": "2017-12-03 17:33:00",
                "moonset": "2017-12-04 07:05:00",
                "predictDate": "2017-12-03",
                "sunrise": "2017-12-03 06:48:00",
                "sunset": "2017-12-03 17:39:00",
                "tempDay": "24",
                "tempNight": "16",
                "updatetime": "2017-11-29 20:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "2",
                "windLevelNight": "2",
                "windSpeedDay": "3.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-04 18:30:00",
                "moonset": "2017-12-05 08:11:00",
                "predictDate": "2017-12-04",
                "sunrise": "2017-12-04 06:49:00",
                "sunset": "2017-12-04 17:39:00",
                "tempDay": "25",
                "tempNight": "17",
                "updatetime": "2017-11-29 20:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-05 19:32:00",
                "moonset": "2017-12-06 09:14:00",
                "predictDate": "2017-12-05",
                "sunrise": "2017-12-05 06:49:00",
                "sunset": "2017-12-05 17:39:00",
                "tempDay": "23",
                "tempNight": "15",
                "updatetime": "2017-11-29 20:07:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4",
                "windLevelNight": "4",
                "windSpeedDay": "7.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-06 20:35:00",
                "moonset": "2017-12-07 10:12:00",
                "predictDate": "2017-12-06",
                "sunrise": "2017-12-06 06:50:00",
                "sunset": "2017-12-06 17:39:00",
                "tempDay": "21",
                "tempNight": "13",
                "updatetime": "2017-11-29 20:08:00",
                "windDirDay": "微风",
                "windDirNight": "东北风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-07 21:39:00",
                "moonset": "2017-12-08 11:04:00",
                "predictDate": "2017-12-07",
                "sunrise": "2017-12-07 06:51:00",
                "sunset": "2017-12-07 17:39:00",
                "tempDay": "20",
                "tempNight": "13",
                "updatetime": "2017-11-29 20:08:00",
                "windDirDay": "北风",
                "windDirNight": "东风",
                "windLevelDay": "3",
                "windLevelNight": "3",
                "windSpeedDay": "5.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "阴",
                "conditionIdDay": "2",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-08 22:41:00",
                "moonset": "2017-12-09 11:52:00",
                "predictDate": "2017-12-08",
                "sunrise": "2017-12-08 06:51:00",
                "sunset": "2017-12-08 17:40:00",
                "tempDay": "21",
                "tempNight": "12",
                "updatetime": "2017-11-29 20:08:00",
                "windDirDay": "北风",
                "windDirNight": "北风",
                "windLevelDay": "4",
                "windLevelNight": "4",
                "windSpeedDay": "7.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningGibbous",
                "moonrise": "2017-12-09 23:41:00",
                "moonset": "2017-12-10 12:34:00",
                "predictDate": "2017-12-09",
                "sunrise": "2017-12-09 06:52:00",
                "sunset": "2017-12-09 17:40:00",
                "tempDay": "19",
                "tempNight": "10",
                "updatetime": "2017-11-29 20:08:00",
                "windDirDay": "西南风",
                "windDirNight": "东南风",
                "windLevelDay": "3-4",
                "windLevelNight": "3-4",
                "windSpeedDay": "6.0",
                "windSpeedNight": "6.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "Last",
                "moonrise": "None",
                "moonset": "2017-12-10 12:34:00",
                "predictDate": "2017-12-10",
                "sunrise": "2017-12-10 06:53:00",
                "sunset": "2017-12-10 17:40:00",
                "tempDay": "18",
                "tempNight": "10",
                "updatetime": "2017-11-29 20:08:00",
                "windDirDay": "东北风",
                "windDirNight": "东风",
                "windLevelDay": "4",
                "windLevelNight": "4",
                "windSpeedDay": "7.0",
                "windSpeedNight": "7.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-11 00:37:00",
                "moonset": "2017-12-11 13:14:00",
                "predictDate": "2017-12-11",
                "sunrise": "2017-12-11 06:53:00",
                "sunset": "2017-12-11 17:40:00",
                "tempDay": "18",
                "tempNight": "12",
                "updatetime": "2017-11-29 20:08:00",
                "windDirDay": "东南风",
                "windDirNight": "东南风",
                "windLevelDay": "4",
                "windLevelNight": "3",
                "windSpeedDay": "7.0",
                "windSpeedNight": "5.0"
            },
            {
                "conditionDay": "晴",
                "conditionIdDay": "0",
                "conditionIdNight": "31",
                "conditionNight": "多云",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-12 01:32:00",
                "moonset": "2017-12-12 13:52:00",
                "predictDate": "2017-12-12",
                "sunrise": "2017-12-12 06:54:00",
                "sunset": "2017-12-12 17:41:00",
                "tempDay": "21",
                "tempNight": "14",
                "updatetime": "2017-11-29 20:08:00",
                "windDirDay": "东北风",
                "windDirNight": "西北风",
                "windLevelDay": "3",
                "windLevelNight": "2",
                "windSpeedDay": "5.0",
                "windSpeedNight": "3.0"
            },
            {
                "conditionDay": "多云",
                "conditionIdDay": "1",
                "conditionIdNight": "2",
                "conditionNight": "阴",
                "moonphase": "WaningCrescent",
                "moonrise": "2017-12-13 02:24:00",
                "moonset": "2017-12-13 14:29:00",
                "predictDate": "2017-12-13",
                "sunrise": "2017-12-13 06:54:00",
                "sunset": "2017-12-13 17:41:00",
                "tempDay": "21",
                "tempNight": "15",
                "updatetime": "2017-11-29 20:08:00",
                "windDirDay": "东北风",
                "windDirNight": "东北风",
                "windLevelDay": "4",
                "windLevelNight": "3",
                "windSpeedDay": "7.0",
                "windSpeedNight": "5.0"
            }
        ],
        "hourly": [
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "19",
                "humidity": "79",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "26",
                "temp": "24",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "多云",
                "date": "2017-11-29",
                "hour": "20",
                "humidity": "81",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "25",
                "temp": "24",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "21",
                "humidity": "81",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "25",
                "temp": "23",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-29",
                "hour": "22",
                "humidity": "84",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "24",
                "temp": "22",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-29",
                "hour": "23",
                "humidity": "87",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "21",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "0",
                "humidity": "87",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "1",
                "humidity": "85",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "ESE",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "2",
                "humidity": "85",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "22",
                "temp": "20",
                "uvi": "0",
                "windDir": "E",
                "windSpeed": "9"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "3",
                "humidity": "87",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "E",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "4",
                "humidity": "86",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "23",
                "temp": "20",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "5",
                "humidity": "85",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "22",
                "temp": "20",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "6",
                "humidity": "83",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "22",
                "temp": "20",
                "uvi": "0",
                "windDir": "ENE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "7",
                "humidity": "83",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "21",
                "temp": "20",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "9"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "8",
                "humidity": "77",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "22",
                "temp": "21",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "9",
                "humidity": "70",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "24",
                "temp": "22",
                "uvi": "2",
                "windDir": "NE",
                "windSpeed": "9"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "10",
                "humidity": "63",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "26",
                "temp": "23",
                "uvi": "3",
                "windDir": "NE",
                "windSpeed": "11"
            },
            {
                "condition": "晴",
                "date": "2017-11-30",
                "hour": "11",
                "humidity": "57",
                "iconDay": "0",
                "iconNight": "30",
                "pressure": "0",
                "realFeel": "27",
                "temp": "24",
                "uvi": "4",
                "windDir": "NE",
                "windSpeed": "11"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "12",
                "humidity": "52",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "28",
                "temp": "24",
                "uvi": "4",
                "windDir": "NE",
                "windSpeed": "11"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "13",
                "humidity": "49",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "28",
                "temp": "24",
                "uvi": "4",
                "windDir": "NE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "14",
                "humidity": "47",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "28",
                "temp": "24",
                "uvi": "3",
                "windDir": "NE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "15",
                "humidity": "49",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "27",
                "temp": "24",
                "uvi": "2",
                "windDir": "NE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "16",
                "humidity": "50",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "26",
                "temp": "24",
                "uvi": "1",
                "windDir": "NE",
                "windSpeed": "12"
            },
            {
                "condition": "阴",
                "date": "2017-11-30",
                "hour": "17",
                "humidity": "54",
                "iconDay": "2",
                "iconNight": "2",
                "pressure": "0",
                "realFeel": "24",
                "temp": "24",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "12"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "18",
                "humidity": "56",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "23",
                "temp": "23",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "12"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "19",
                "humidity": "58",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "22",
                "temp": "22",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "12"
            },
            {
                "condition": "少云",
                "date": "2017-11-30",
                "hour": "20",
                "humidity": "58",
                "iconDay": "1",
                "iconNight": "31",
                "pressure": "0",
                "realFeel": "21",
                "temp": "20",
                "uvi": "0",
                "windDir": "NE",
                "windSpeed": "12"
            }
        ],
        "liveIndex": {
            "2017-11-29": [
                {
                    "code": 7,
                    "day": "2017-11-29",
                    "desc": "建议用露质面霜打底，水质无油粉底霜，透明粉饼，粉质胭脂。",
                    "level": "10",
                    "name": "化妆指数",
                    "status": "控油"
                },
                {
                    "code": 12,
                    "day": "2017-11-29",
                    "desc": "感冒容易发生，少去人群密集的场所有利于降低感冒的几率。",
                    "level": "4",
                    "name": "感冒指数",
                    "status": "易发"
                },
                {
                    "code": 17,
                    "day": "2017-11-29",
                    "desc": "洗车后，只能保持1天车辆清洁，不太适宜洗车。",
                    "level": "7",
                    "name": "洗车指数",
                    "status": "较不适宜"
                },
                {
                    "day": "2017-11-29",
                    "desc": "气象条件有利于空气污染物扩散。",
                    "level": "None",
                    "name": "空气污染扩散指数",
                    "status": "良"
                },
                {
                    "code": 20,
                    "day": "2017-11-29",
                    "desc": "天气较热，衣物精干简洁，室内酌情添加空调衫。",
                    "level": "3",
                    "name": "穿衣指数",
                    "status": "热"
                },
                {
                    "code": 21,
                    "day": "2017-11-29",
                    "desc": "辐射弱，涂擦SPF8-12防晒护肤品。",
                    "level": "1",
                    "name": "紫外线指数",
                    "status": "最弱"
                },
                {
                    "code": 26,
                    "day": "2017-11-29",
                    "desc": "天气较好，且紫外线辐射不强，适宜户外运动。",
                    "level": "1",
                    "name": "运动指数",
                    "status": "适宜"
                },
                {
                    "code": 28,
                    "day": "2017-11-29",
                    "desc": "气压小幅波动，可能会影响鱼儿的进食。",
                    "level": "8",
                    "name": "钓鱼指数",
                    "status": "较适宜"
                }
            ]
        },
        "sfc": {
            "banner": "未来一小时不会下雨",
            "notice": "未来一小时不会下雨",
            "percent": [
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                },
                {
                    "desc": "无雨",
                    "icon": -1,
                    "percent": 0.0
                }
            ],
            "rain": 0,
            "sfCondition": 1,
            "timestamp": 1510356543000
        }
    },
    "msg": "success",
    "rc": {
        "c": 0,
        "p": "success"
    }
}
